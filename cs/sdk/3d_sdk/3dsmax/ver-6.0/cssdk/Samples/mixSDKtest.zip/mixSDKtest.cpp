/**********************************************************************
 *<
	FILE: mixSDKtest.cpp

	DESCRIPTION:  A utility to test the biped mixer SDK

	CREATED BY: Susan Amkraut

	HISTORY: created 04/07/03

 *>	Copyright (c) 2003, All Rights Reserved.
 **********************************************************************/
#include "mixSDKtest.h"
#include "utilapi.h"

#include "E:\cujo-devel\3dswin\src\dll\biped\bipedsdk\bipedapi.h"
#include "E:\cujo-devel\3dswin\src\dll\biped\bipedsdk\imixer.h"

#define MIXSDKTEST_CLASS_ID		Class_ID(0x1cb87898, 0x4b324226)
#define MIXSDKTEST_CNAME		GetString(IDS_MIXSDKTEST)

class MixSDKUtil : public UtilityObj {
	public:
		IUtil *iu;
		Interface *ip;
		HWND hPanel;

		MixSDKUtil() {};
		void BeginEditParams(Interface *ip,IUtil *iu);
		void EndEditParams(Interface *ip,IUtil *iu);
		void DeleteThis() {}
		void SelectionSetChanged(Interface *ip,IUtil *iu);
		BOOL IsBipedNode(INode *node);

		void Init(HWND hWnd);
		void Destroy(HWND hWnd);

		void TestBipedMixerAPI();
	};

static MixSDKUtil theMixSDKUtil;

class MixSDKUtilClassDesc:public ClassDesc {
	public:
	int 			IsPublic() {return 1;}
	void *			Create(BOOL loading = FALSE) {return &theMixSDKUtil;}
	const TCHAR *	ClassName() {return MIXSDKTEST_CNAME;}
	SClass_ID		SuperClassID() {return UTILITY_CLASS_ID;}
	Class_ID		ClassID() {return MIXSDKTEST_CLASS_ID;}
	const TCHAR* 	Category() {return _T("");}
	};

static MixSDKUtilClassDesc MixSDKUtilDesc;
ClassDesc* GetMixSDKUtilDesc() {return &MixSDKUtilDesc;}


static INT_PTR CALLBACK MixSDKUtilDlgProc(
		HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
	{
	switch (msg) {
		case WM_INITDIALOG:
			theMixSDKUtil.Init(hWnd);
			break;

		case WM_DESTROY:
			theMixSDKUtil.Destroy(hWnd);
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam)) {
				case IDOK:
					theMixSDKUtil.iu->CloseUtility();
					break;

				case IDC_MIXSDKTEST:
					theMixSDKUtil.TestBipedMixerAPI();
					break;
				}
			break;

		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_MOUSEMOVE:
			theMixSDKUtil.ip->RollupMouseMessage(hWnd,msg,wParam,lParam); 
			break;

		default:
			return FALSE;
		}
	return TRUE;
	}	

void MixSDKUtil::BeginEditParams(Interface *ip,IUtil *iu) 
	{
	this->iu = iu;
	this->ip = ip;
	hPanel = ip->AddRollupPage(
		hInstance,
		MAKEINTRESOURCE(IDD_MIXSDKTEST_PANEL),
		MixSDKUtilDlgProc,
		GetString(IDS_MIXSDKTEST),
		0);
	}
  
void MixSDKUtil::EndEditParams(Interface *ip,IUtil *iu) 
	{
	this->iu = NULL;
	this->ip = NULL;
	ip->DeleteRollupPage(hPanel);
	hPanel = NULL;
	}

void MixSDKUtil::Init(HWND hWnd)
	{
	hPanel = hWnd;
	SelectionSetChanged(ip,iu);	
	}

void MixSDKUtil::Destroy(HWND hWnd)
	{		
	hPanel = NULL;
	}

void MixSDKUtil::SelectionSetChanged(Interface *ip,IUtil *iu)
{
	if (ip->GetSelNodeCount()==1) 
	{
		SetDlgItemText(hPanel,IDC_SEL_NAME,ip->GetSelNode(0)->GetName());
	    if (IsBipedNode(ip->GetSelNode(0)) )
			 EnableWindow(GetDlgItem(hPanel,IDC_MIXSDKTEST),true);
		else EnableWindow(GetDlgItem(hPanel,IDC_MIXSDKTEST),false);
		return;
	} 
	else if (ip->GetSelNodeCount()) 
		SetDlgItemText(hPanel,IDC_SEL_NAME,GetString(IDS_MULTISEL));
			else SetDlgItemText(hPanel,IDC_SEL_NAME,GetString(IDS_NONESEL));
	EnableWindow(GetDlgItem(hPanel,IDC_MIXSDKTEST),false);
}

void MixSDKUtil::TestBipedMixerAPI()
{
	// Get the selected node, and check if it's a biped
	if (ip->GetSelNodeCount()!=1) return;
	INode *node = ip->GetSelNode(0);
	if (!IsBipedNode(node)) return;

	// Get the node's transform control
	Control *c = node->GetTMController();

	// Get the Biped Export Interface from the controller 
	IBipMaster *iBipMas = (IBipMaster *) c->GetInterface(I_BIPMASTER);

	// Put the biped in mixer mode
	iBipMas->BeginModes(BMODE_MIXER);

	// Get the mixer from the biped
	IMixer *MX = iBipMas->GetMixer();

	// Clear the mixer, in case it has something in it
	MX->ClearMixer();

	// Insert a trackgroup in the mixer
	MX->InsertTrackgroup(0);

	// Get the trackgroup
	IMXtrackgroup *TG = MX->GetTrackgroup(0);

	// Get the track created by default in the trackgroup
	IMXtrack *TK = TG->GetTrack(0);

	// Set it to be a transition track
	TK->SetTrackType(TRANSTRACK);

	// Append 5 of the same clips to the track, and scale each of them
	// You need to scale before appending the next one, or else you will have overlapping clips
	// You need to compute the transition clips as you go, since you've changed the transition track
	IMXclip *CP;
	int i;
	float startscale = 1.3f;
	for (i=0; i<5; i++)
	{
		if (!TK->AppendClip("E:\\Examples\\jog.bip")) return;
		TK->ComputeTransClips();
		CP = TK->GetTransClip(i);
		CP->ScaleClip(startscale - (.1 * i)); // scale a little faster each time
	}
	
	// Optimize all transitions for the entire track
	TK->OptimizeTransitions(10, true, 10, 10);

	// Reset the angle, the transition focus, and rolling/fixed for each clip's transition
	for (i=0; i<TK->NumTransClips(); i++)
	{
		CP = TK->GetTransClip(i);
		CP->SetNextTransitionAngle(10.0f);
		CP->SetNextTransitionFocus(FOCUS_AUTO);
		CP->SetNextTransitionRolling(); 
	}

        // copy the original, unscaled clip to the biped (visible when not in mixer mode)
	MX->CopyClipSourceToBiped(TK->GetTransClip(0));

	// Invalidate raw mix so it will be recomputed when the biped is updated
	MX->InvalidateRawMix();

	// Mixdown and effect the mixdown
	MX->Mixdown(true, true, 6, true, 20.0f);
	MX->EffectMixdown();

	// add this biped to the display, show the mixer, zoom extents, set animation range, 
	// hide the balance curve, and update mixer display
	MX->AddToDisplay();
	MX->SetShowBalance(false);
	MX->ShowMixer();
	MX->ZoomExtents();
	MX->SetAnimationRange();
	MX->UpdateDisplay();
}

BOOL MixSDKUtil::IsBipedNode(INode *node)
{
    Control *c = node->GetTMController();
	if (!c) return false;
	if (c->ClassID() == BIPSLAVE_CONTROL_CLASS_ID) return true;
	if (c->ClassID() == BIPBODY_CONTROL_CLASS_ID) return true;
	if (c->ClassID() == FOOTPRINT_CLASS_ID) return true;
	return false;
}
