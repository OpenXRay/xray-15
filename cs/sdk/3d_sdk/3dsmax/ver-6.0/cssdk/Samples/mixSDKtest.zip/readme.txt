
This directory contains a sample utility plugin which tests a subset of the Biped Mixer SDK.

To run the utility:

1. Put mixSDKtest.dlu inside your 3dsmax/exe/plugins directory.
2. Start 3ds Max.
3. Create a biped.
4. Go to the utilities panel, click on "More...", and select "mixSDKtest".
5. Select a part of the biped.
6. Click the "Mix SDK Test" button.

Now the SDK test will use the mixer SDK to add a trackgroup and a transition track to the selected biped's mixer.
It then appends 5 jog clips (you need to make sure you have the jog.bip file in the appropriate directory) to the track.
As it appends the clips, it gradually scales them to go from slow to fast.
It then sets the transition angle to 10 for all transitions, which causes the biped to turn while jogging.
It computes a mixdown and makes the biped perform the mixdown.
Then it adds the biped to the mixer, shows the mixer, sets the animation range to match the mixer animation, and does a zoom extents.



To compile the utility:

Unzip this into your maxsdk directory.  Load the plugin, and compile.
