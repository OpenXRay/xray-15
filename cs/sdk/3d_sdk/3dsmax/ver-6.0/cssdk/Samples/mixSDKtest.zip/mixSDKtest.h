/**********************************************************************
 *<
	FILE: mixSDKtest.h

	DESCRIPTION:

	CREATED BY: Susan Amkraut

	HISTORY: created 04/07/03

 *>	Copyright (c) 2003, All Rights Reserved.
 **********************************************************************/

#ifndef __UTIL__H
#define __UTIL__H

#include "Max.h"
#include "resource.h"

TCHAR *GetString(int id);

extern ClassDesc* GetMixSDKUtilDesc();

extern HINSTANCE hInstance;

#endif
