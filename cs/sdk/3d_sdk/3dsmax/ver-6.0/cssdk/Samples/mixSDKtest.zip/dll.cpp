/**********************************************************************
 *<
	FILE: dll.cpp

	DESCRIPTION:   utility

	CREATED BY: Susan Amkraut

	HISTORY: created 04/07/03

 *>	Copyright (c) 2003, All Rights Reserved.
 **********************************************************************/

#include "mixSDKtest.h"

HINSTANCE hInstance;
int controlsInit = FALSE;

/** public functions **/
BOOL WINAPI DllMain(HINSTANCE hinstDLL,ULONG fdwReason,LPVOID lpvReserved) {
	hInstance = hinstDLL;

	if (!controlsInit) {
		controlsInit = TRUE;

		// jaguar controls
		InitCustomControls(hInstance);
		
		// initialize Chicago controls
		InitCommonControls();
		}
			
	return (TRUE);
	}


//------------------------------------------------------
// This is the interface to Jaguar:
//------------------------------------------------------

__declspec( dllexport ) const TCHAR *
LibDescription() { return GetString(IDS_LIBDESC); }

__declspec( dllexport ) int LibNumberClasses() {

	return 1;
	}


__declspec( dllexport ) ClassDesc*
LibClassDesc(int i) {

	if (i==0)
		return GetMixSDKUtilDesc();
	else
		return NULL;
}


// Return version so can detect obsolete DLLs
__declspec( dllexport ) ULONG 
LibVersion() { return VERSION_3DSMAX; }

TCHAR *GetString(int id)
	{
	static TCHAR buf[256];

	if (hInstance)
		return LoadString(hInstance, id, buf, sizeof(buf)) ? buf : NULL;
	return NULL;
	}

