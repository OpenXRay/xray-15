/**********************************************************************
 *<
	FILE: KeyReducer.cpp

	DESCRIPTION:	Trackview Utility for Key reduction

	CREATED BY: Nikolai Sander, Kinetix

	HISTORY: created 9/26/98

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/

#include "PhysCollapse.h"
#include "keyreduc.h"
#include "tvutil.h"

#define KEYREDUCER_CLASS_ID	Class_ID(0x81048419, 0x6e68c10e)

class MyKeyReduceStatus : public KeyReduceStatus
{
	void Init(int i){}
	int  Progress(int i){return KEYREDUCE_CONTINUE;}
};

#define SHOWPROGRESSBARLIMIT 200

DWORD WINAPI fnd(LPVOID arg) 
{
	
	return 0;

}

class KeyReducer : public TrackViewUtility {
	
	public:

		ITVUtility *iu;
		Interface *ip;
		HWND hPanel;
		ISpinnerControl *iThresh;	
		float thresh;
		//Constructor/Destructor
		KeyReducer();
		~KeyReducer();

		void BeginEditParams(Interface *ip,ITVUtility *iu);
		void EndEditParams(Interface *ip,ITVUtility *iu);
		void DeleteThis();
		
		void Init(HWND hWnd);
		void Destroy(HWND hWnd);

		void TrackSelectionChanged();
		void NodeSelectionChanged();
		void KeySelectionChanged();
		void TimeSelectionChanged();
		void MajorModeChanged();
		void TrackListChanged();
		void ReduceKeys();
};


static KeyReducer theKeyReducer;

class KeyReducerClassDesc:public ClassDesc {
	public:
	int 			IsPublic() {return 1;}
	void *			Create(BOOL loading = FALSE) {return &theKeyReducer;}
	const TCHAR *	ClassName() {return GetString(IDS_KR_CLASS_NAME);}
	SClass_ID		SuperClassID() {return TRACKVIEW_UTILITY_CLASS_ID;}
	Class_ID		ClassID() {return KEYREDUCER_CLASS_ID;}
	const TCHAR* 	Category() {return GetString(IDS_CATEGORY);}
	void			ResetClassParams (BOOL fileReset);
};

static KeyReducerClassDesc KeyReducerDesc;
ClassDesc* GetKeyReducerDesc() {return &KeyReducerDesc;}

//TODO: Should implement this method to reset the plugin params when Max is reset
void KeyReducerClassDesc::ResetClassParams (BOOL fileReset) 
{

}

static BOOL CALLBACK KeyReducerDlgProc(
		HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	
	if (((msg==CC_SPINNER_BUTTONUP) && HIWORD(wParam)) ||
	((msg==CC_SPINNER_CHANGE) ))// && (!HIWORD(wParam)))) 
	{
		ISpinnerControl *spin;
		spin = (ISpinnerControl *) lParam;
		
		switch (LOWORD(wParam)) 
		{
		case IDC_THRESHSPIN:
			if ((msg == CC_SPINNER_CHANGE))// || (!HIWORD(wParam))) 
			{
				theKeyReducer.thresh = spin->GetFVal();
			}
			break;
		}
	}
	switch (msg) {
		case WM_INITDIALOG:
			theKeyReducer.Init(hWnd);
			CenterWindow(hWnd,GetParent(hWnd));
			break;

		case WM_DESTROY:
			theKeyReducer.Destroy(hWnd);
			break;

		case WM_COMMAND:
			switch (LOWORD(wParam)) {				
				case IDC_REDUCEKEYS:
					theKeyReducer.ReduceKeys();
					//EndDialog(hWnd,1);
					break;
			}
			break;
		case WM_CLOSE:
			DestroyWindow(hWnd);
			break;

		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_MOUSEMOVE:
			theKeyReducer.ip->RollupMouseMessage(hWnd,msg,wParam,lParam); 
			break;

		default:
			return FALSE;
	}
	return TRUE;
}


	
KeyReducer::KeyReducer()
{
	iu = NULL;
	ip = NULL;	
	hPanel = NULL;
	thresh = 0;
	iThresh = NULL;
}

KeyReducer::~KeyReducer()
{

}

void KeyReducer::BeginEditParams(Interface *ip,ITVUtility *iu)
{
	this->iu = iu;
	this->ip = ip;
	hPanel = CreateDialogParam(
		hInstance,
		MAKEINTRESOURCE(IDD_KEYREDUCER),
		iu->GetTrackViewHWnd(),
		KeyReducerDlgProc,
		(LONG)this);
		
	iThresh = SetupFloatSpinner (hPanel, IDC_THRESHSPIN, IDC_THRESH, 0.0, 1000.0, thresh);
}

void KeyReducer::EndEditParams(Interface *ip,ITVUtility *iu)
{
	this->iu = NULL;
	this->ip = NULL;
	ip->DeleteRollupPage(hPanel);
	hPanel = NULL;
	ReleaseISpinner(iThresh);
}

void KeyReducer::DeleteThis()
{

}

void KeyReducer::TrackSelectionChanged()
{

}

void KeyReducer::NodeSelectionChanged()
{

}

void KeyReducer::KeySelectionChanged()
{

}

void KeyReducer::TimeSelectionChanged()
{

}

void KeyReducer::MajorModeChanged()
{

}

void KeyReducer::TrackListChanged()
{

}

void KeyReducer::Init(HWND hWnd)
{

}

void KeyReducer::Destroy(HWND hWnd)
{

}

void KeyReducer::ReduceKeys()
{
	
	theHold.SuperBegin();

	int startnumkeys = 0;
	int retval;
	int endnumkeys = 0;
	Tab<TimeValue> times;
	Interval range = ip->GetAnimRange();
	TSTR str;
	int numctls = 0;
	int icurctl = 0;
	for(int iNumTrack = 0 ; iNumTrack < iu->GetNumTracks() ; iNumTrack++)
	{
		if(iu->IsSelected(iNumTrack))
		{
		//	DebugPrint("%s",iu->GetTrackName(iNumTrack));
			Animatable *anim = iu->GetAnim(iNumTrack);
			if(anim->SuperClassID() == 	CTRL_FLOAT_CLASS_ID ||
				anim->SuperClassID() == CTRL_POINT3_CLASS_ID ||
				anim->SuperClassID() == CTRL_MATRIX3_CLASS_ID ||
				anim->SuperClassID() == CTRL_POSITION_CLASS_ID ||
				anim->SuperClassID() == CTRL_ROTATION_CLASS_ID ||
				anim->SuperClassID() == CTRL_SCALE_CLASS_ID ||
				anim->SuperClassID() == CTRL_MORPH_CLASS_ID )
			{
				numctls++;
				anim->GetKeyTimes(times,range,0);
				startnumkeys += times.Count();
				times.SetCount(0);
			}
		}
	}
	
	if(startnumkeys > SHOWPROGRESSBARLIMIT )
		ip->ProgressStart(_T("Reducing Keys"), TRUE, fnd, this);
	
	for(iNumTrack = 0 ; iNumTrack < iu->GetNumTracks() ; iNumTrack++)
	{
		if(iu->IsSelected(iNumTrack))
		{
		//	DebugPrint("%s",iu->GetTrackName(iNumTrack));
			Animatable *anim = iu->GetAnim(iNumTrack);
			if(anim->SuperClassID() == 	CTRL_FLOAT_CLASS_ID ||
				anim->SuperClassID() == CTRL_POINT3_CLASS_ID ||
				anim->SuperClassID() == CTRL_MATRIX3_CLASS_ID ||
				anim->SuperClassID() == CTRL_POSITION_CLASS_ID ||
				anim->SuperClassID() == CTRL_ROTATION_CLASS_ID ||
				anim->SuperClassID() == CTRL_SCALE_CLASS_ID ||
				anim->SuperClassID() == CTRL_MORPH_CLASS_ID )
			{
				Control *pctl = (Control *) anim;
				MyKeyReduceStatus status;
				ApplyKeyReduction(pctl,range,thresh,GetTicksPerFrame(), &status);
				anim->GetKeyTimes(times,range,0);
				endnumkeys += times.Count();
				times.SetCount(0);
				if(startnumkeys > SHOWPROGRESSBARLIMIT )
				{
					ip->ProgressUpdate( (int)(icurctl/(float)numctls*100));
					
					if (ip->GetCancel()) {
						retval = MessageBox(ip->GetMAXHWnd(), _T("Do you want to cancel the key reduction ?"),
							_T("Question"), MB_ICONQUESTION | MB_YESNO);
						if (retval == IDYES)
						{
							theHold.SuperCancel();
							ip->ProgressEnd();
							return;
						}
						else if (retval == IDNO)
							ip->SetCancel(FALSE);
					}
				}
				icurctl++;

			}	
		}
	}
	ip->ProgressEnd();

	str.printf("%d",startnumkeys);
	SetDlgItemText(hPanel,IDC_STARTNUMKEYS,str);
	
	str.printf("%d",endnumkeys);
	SetDlgItemText(hPanel,IDC_ENDNUMKEYS,str);

	str.printf("%d",startnumkeys-endnumkeys);
	SetDlgItemText(hPanel,IDC_REDUCEDKEYS,str);

	theHold.SuperAccept("ReduceKeys");
	
	return;
}