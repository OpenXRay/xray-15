/**********************************************************************
 *<
	FILE: PhysCollapse.h

	DESCRIPTION:	Collapse a Physique Mesh

	CREATED BY: Nikolai Sander, Kinetix
 
 	HISTORY: created 9/26/98

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/


#ifndef __PHYSCOLLAPSE__H
#define __PHYSCOLLAPSE__H

#include "Max.h"
#include "resource.h"
#include "istdplug.h"


#include "utilapi.h"

extern TCHAR *GetString(int id);

extern HINSTANCE hInstance;

#endif // __PHYSCOLLAPSE__H
