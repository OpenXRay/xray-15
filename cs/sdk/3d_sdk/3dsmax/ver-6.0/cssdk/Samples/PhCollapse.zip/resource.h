//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PhysCollapse.rc
//
#define IDS_LIBDESCRIPTION              1
#define IDS_CATEGORY                    2
#define IDS_CLASS_NAME                  3
#define IDS_PARAMS                      4
#define IDS_RB_EDITABLEMESH             5
#define IDS_RB_MULTIATTACH              6
#define IDS_RB_ATTACH                   7
#define IDS_KR_CLASS_NAME               8
#define IDD_PHYSCOLLAPSE                101
#define IDD_KEYREDUCER                  102
#define IDC_CLOSEBUTTON                 1000
#define IDC_COLLAPSE                    1001
#define IDC_REDUCEKEYS                  1002
#define IDC_INCNODETM                   1003
#define IDC_STARTNUMKEYS                1004
#define IDC_UNLINK_MESH                 1005
#define IDC_ENDNUMKEYS                  1006
#define IDC_ADDLXFORM                   1007
#define IDC_REDUCEDKEYS                 1008
#define IDC_MTPHYSIQUE                  1009
#define IDC_COLOR                       1456
#define IDC_EDIT                        1490
#define IDC_THRESH                      1490
#define IDC_SPIN                        1496
#define IDC_THRESHSPIN                  1496

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
