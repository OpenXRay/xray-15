/**********************************************************************
 *<
	FILE: PhysCollapse.cpp

	DESCRIPTION:	Collapse a Physique Mesh

	CREATED BY: Nikolai Sander, Kinetix
 
 	HISTORY: created 9/26/98
			 updated for MAX R3 3/15/99

 *>	Copyright (c) 1997, All Rights Reserved.
 **********************************************************************/

#include "PhysCollapse.h"
#include "Phyexp.h"
#include "modstack.h"

#define ET_VERT_BASE_REF 1


#define PHYSCOLLAPSE_CLASS_ID	Class_ID(0x72829b8c, 0x776923f1)

class PhysCollapse : public UtilityObj {
	
	BOOL incnodetm;
	BOOL unlinkmesh;
	

	int iTotal;
	int iNode;

public:

		IUtil *iu;
		Interface *ip;
		HWND hPanel;
		int num_deformable_points;
		IPhyContextExport *mcExport;
		TriObject *tri;
		INode *node;

		//Constructor/Destructor
		PhysCollapse();
		~PhysCollapse();

		void BeginEditParams(Interface *ip,IUtil *iu);
		void EndEditParams(Interface *ip,IUtil *iu);
		void DeleteThis() {}
		void Init(HWND hWnd);
		void Destroy(HWND hWnd);

		void Collapse();
		TriObject *CollapseToMesh(INode *node, Object **oldObject);
		BOOL CollapsePhyAnim(INode* node);
		void SampleNode(INode *node, INode *newNode);
};


static PhysCollapse thePhysCollapse;

class PhysCollapseClassDesc:public ClassDesc {
	public:
	int 			IsPublic() {return 1;}
	void *			Create(BOOL loading = FALSE) {return &thePhysCollapse;}
	const TCHAR *	ClassName() {return GetString(IDS_CLASS_NAME);}
	SClass_ID		SuperClassID() {return UTILITY_CLASS_ID;}
	Class_ID		ClassID() {return PHYSCOLLAPSE_CLASS_ID;}
	const TCHAR* 	Category() {return GetString(IDS_CATEGORY);}
	void			ResetClassParams (BOOL fileReset);
};

static PhysCollapseClassDesc PhysCollapseDesc;
ClassDesc* GetPhysCollapseDesc() {return &PhysCollapseDesc;}

//TODO: Should implement this method to reset the plugin params when Max is reset
void PhysCollapseClassDesc::ResetClassParams (BOOL fileReset) 
{

}

static BOOL CALLBACK PhysCollapseDlgProc(
		HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch (msg) {
		case WM_INITDIALOG:
			thePhysCollapse.Init(hWnd);
			break;

		case WM_DESTROY:
			thePhysCollapse.Destroy(hWnd);
			break;

		case WM_COMMAND:

			switch (LOWORD(wParam)) 
			{
				case IDC_COLLAPSE:
					thePhysCollapse.Collapse();
					break;
			}
			break;
		case WM_LBUTTONDOWN:
		case WM_LBUTTONUP:
		case WM_MOUSEMOVE:
			thePhysCollapse.ip->RollupMouseMessage(hWnd,msg,wParam,lParam); 
			break;

		default:
			return FALSE;
	}
	return TRUE;
}

DWORD WINAPI fn(LPVOID arg) 
{
	
	return 0;

}

// --- From Phyexp.h ------------------------------------------------------
// example code to find if a given node contains a Physique Modifier
// DerivedObjectPtr requires you include "modstack.h" from the MAX SDK

Modifier* FindPhysiqueModifier (INode* nodePtr)
{
	// Get object from node. Abort if no object.
	Object* ObjectPtr = nodePtr->GetObjectRef();
	

	if (!ObjectPtr) return NULL;

	// Is derived object ?
	if (ObjectPtr->SuperClassID() == GEN_DERIVOB_CLASS_ID)
	{
		// Yes -> Cast.
		IDerivedObject* DerivedObjectPtr = static_cast<IDerivedObject*>(ObjectPtr);

		// Iterate over all entries of the modifier stack.
		int ModStackIndex = 0;
		while (ModStackIndex < DerivedObjectPtr->NumModifiers())
		{
			// Get current modifier.
			Modifier* ModifierPtr = DerivedObjectPtr->GetModifier(ModStackIndex);

			// Is this Physique ?
			if (ModifierPtr->ClassID() == Class_ID(PHYSIQUE_CLASS_ID_A, PHYSIQUE_CLASS_ID_B))
			{
				// Yes -> Exit.
				return ModifierPtr;
			}

			// Next modifier stack entry.
			ModStackIndex++;
		}
	}

	// Not found.
	return NULL;
}

//--- PhysCollapse -------------------------------------------------------
PhysCollapse::PhysCollapse()
{
	iu = NULL;
	ip = NULL;	
	hPanel = NULL;
	incnodetm = TRUE;
	unlinkmesh = TRUE;
}

PhysCollapse::~PhysCollapse()
{

}

void PhysCollapse::BeginEditParams(Interface *ip,IUtil *iu) 
{
	this->iu = iu;
	this->ip = ip;
	hPanel = ip->AddRollupPage(
		hInstance,
		MAKEINTRESOURCE(IDD_PHYSCOLLAPSE),
		PhysCollapseDlgProc,
		GetString(IDS_PARAMS),
		0);
	
	SetCheckBox(hPanel, IDC_INCNODETM, incnodetm);
	SetCheckBox(hPanel, IDC_UNLINK_MESH, unlinkmesh);
}
	
void PhysCollapse::EndEditParams(Interface *ip,IUtil *iu) 
{
	this->iu = NULL;
	this->ip = NULL;
	ip->DeleteRollupPage(hPanel);
	hPanel = NULL;
}

void PhysCollapse::Init(HWND hWnd)
{

}

void PhysCollapse::Destroy(HWND hWnd)
{

}

void PhysCollapse::Collapse()
{
	
	// This is in case the user presses cancel on the progressbar
	theHold.SuperBegin();

	// We only allow 1 node for now 
	if(ip->GetSelNodeCount() != 1)
		return;

	Object *oldObj;
	incnodetm  = GetCheckBox(hPanel, IDC_INCNODETM);
	unlinkmesh  = GetCheckBox(hPanel, IDC_UNLINK_MESH);

	ip->ProgressStart(_T("Processing Vertices"), TRUE, fn, this);
	
	
	// Get the selected node
	node = ip->GetSelNode(0);
	
	tri = CollapseToMesh(node, &oldObj);
	
	iTotal = (int) ip->GetSelNodeCount() * (tri->mesh.getNumVerts());
	
	if(!CollapsePhyAnim(node))
	{
		if (oldObj!=tri) tri->AutoDelete();
		ip->ProgressEnd();
		return;
	}

	if(unlinkmesh)
		SampleNode(node,node);
	
	SetSaveRequiredFlag(TRUE);
	
	oldObj->SetAFlag(A_LOCK_TARGET);
	node->SetObjectRef(tri);		
	oldObj->ClearAFlag(A_LOCK_TARGET);
	if (oldObj!=tri) oldObj->AutoDelete();

	ip->ProgressEnd();
	
	INode *parNode = node->GetParentNode();

	ip->RedrawViews(ip->GetTime());
	theHold.SuperAccept("");
	
	// This can't be undone !
	GetSystemSetting(SYSSET_CLEAR_UNDO);

}

TriObject *PhysCollapse::CollapseToMesh(INode *node, Object **oldObj)
{
	TriObject *tobj = NULL;
	
	// Eval the node's object (exclude WSMs)
	*oldObj = node->GetObjectRef();
	ObjectState os = (*oldObj)->Eval(ip->GetTime());
	Object *obj = (Object*)os.obj->Clone();
	
	if (os.obj->CanConvertToType(triObjectClassID)) {
		
		// Convert it to a TriObject and make that the new object
		tobj = (TriObject*)obj->ConvertToType(ip->GetTime(),triObjectClassID);
	}

	return tobj;
}
	
BOOL PhysCollapse::CollapsePhyAnim(INode* node/*, int indentLevel*/)
{
	Interval anim = ip->GetAnimRange();
	TimeValue TPF = GetTicksPerFrame();

	Modifier *phyMod = FindPhysiqueModifier(node);
	if (!phyMod) return FALSE;	// Physique Modifier does not exist for given Node

	// create a Physique Export Interface for the given Physique Modifier
	IPhysiqueExport *phyExport = (IPhysiqueExport *)phyMod->GetInterface(I_PHYINTERFACE);

	if (phyExport)
	{
		// create a ModContext Export Interface for the specific node of the Physique Modifier
		mcExport = (IPhyContextExport *)phyExport->GetContextInterface(node);

		if (mcExport)
		{
			// Get the number of vertices of the Physique modifier
			num_deformable_points = mcExport->GetNumberVertices();
			
			Matrix3 invntm = Inverse(node->GetObjTMAfterWSM(0));
			INode *bone;
			Matrix3 btm;
			Point3 p3;
			Point3 offsetVector;
			BOOL gotOffsetVector;
			Control *pCP3;
			int time;
			int vertex_type;
			int retval;
			
			for(int i = 0 ; i < num_deformable_points; i++ )
			{
				IPhyVertexExport *vtxExport = (IPhyVertexExport *)mcExport->GetVertexInterface(i);
				if (vtxExport)
				{
					vertex_type = vtxExport->GetVertexType();
					
					if ( (vertex_type | DEFORMABLE_TYPE) || (vertex_type | RIGID_TYPE))
					{

						if(vertex_type == DEFORMABLE_TYPE)
							bone = ((IPhyDeformableOffsetVertex *)vtxExport)->GetNode();
						else
							bone = ((IPhyRigidVertex *)vtxExport)->GetNode();
						
						btm = bone->GetNodeTM(0);
						
						pCP3 = (Control *) tri->GetReference(i+ET_VERT_BASE_REF );
						
						if(!pCP3)
						{
							// This is a fix for an assert that gets thrown if CreateContArray() is not called before 
							// ReplaceReference (because of assert(which<NumRefs()); in DeleteReference())
							// The SetReference causes CreateContArray() to be called and allocates the control array
							// NumRefs is not 0 after that call.
							
							if(tri->NumRefs() <= 1)
								tri->SetReference(ET_VERT_BASE_REF, NULL);
							
							pCP3 = NewDefaultPoint3Controller();
							tri->AssignController(pCP3,i+ET_VERT_BASE_REF );
							
							SuspendAnimate();
							AnimateOn();
							pCP3->SetValue( anim.Start(),tri->mesh.verts[i]);
							ResumeAnimate();
							
						}

						gotOffsetVector = FALSE;

						for(time = anim.Start(); time <= anim.End(); time += TPF )
						{
							
							if(vertex_type == DEFORMABLE_TYPE)
								p3 = ((IPhyDeformableOffsetVertex *)vtxExport)->GetDeformOffsetVector(time);
							else
							{
								// A little optimization. we don't need to evaluate this over and over again
								if(gotOffsetVector)
									p3 = offsetVector;
								else
								{
									p3 = ((IPhyRigidVertex *)vtxExport)->GetOffsetVector();
									offsetVector = p3;
									gotOffsetVector = TRUE;
								}
							}
								
							if(incnodetm)
							{
								p3 = p3 * bone->GetNodeTM(time);
								p3 = p3 * Inverse(node->GetObjTMAfterWSM(time));
							}
							else
							{
								p3 = p3 * btm;
								p3 = p3 * invntm;
							}
							
							
							SuspendAnimate();
							AnimateOn();
							
							// Set the controller value of the animated mesh
							pCP3->SetValue(time, &p3,1,CTRL_ABSOLUTE);
							ResumeAnimate();

							
						} // end time loop
						
					} // if deformable type			
				}// if vtxExport				

				ip->ProgressUpdate((int) ((i/(float)iTotal) * 100));
				if (ip->GetCancel()) {
					retval = MessageBox(ip->GetMAXHWnd(), _T("Do you want to cancel the key reduction ?"),
						_T("Question"), MB_ICONQUESTION | MB_YESNO);
					if (retval == IDYES)
					{
						theHold.SuperCancel();
						ip->ProgressEnd();
						return FALSE;
					}
					else if (retval == IDNO)
						ip->SetCancel(FALSE);
				}				
			}// deformable points
			
			phyExport->ReleaseContextInterface(mcExport);
		}
		
		phyMod->ReleaseInterface(I_PHYINTERFACE, phyExport);
	}
	ip->ProgressUpdate(100);
	return TRUE;
}

// Here we unlink the mesh from the Biped and sample the keyframes
void PhysCollapse::SampleNode(INode *node, INode *newNode)
{
	Interval anim = ip->GetAnimRange();
	TimeValue TPF = GetTicksPerFrame();					
	Matrix3 ntm;
	
	Control *tmControl = NewDefaultMatrix3Controller();
	
	SuspendAnimate();
	AnimateOn();

	// Smaple the nodes TM	
	for(TimeValue time = anim.Start(); time <= anim.End(); time += TPF )
	{
		ntm = node->GetNodeTM(time);
		
		SetXFormPacket pckt(ntm);
		tmControl->SetValue(time,&pckt);		
	}
	
	ResumeAnimate();
	
	// Unlink it from its parent node
	node->Detach(0);
	
	// Assign the just sampled TMController to the node
	node->SetTMController(tmControl);
}

